# Cloud Zone

Arabic gaming site with:
- Public emulator catalog
- Public Steam information cards (display only)
- Multi-admin login and admin management
- JSON persistence

## Run locally / in a Node.js host

1. Install Node.js 18+.
2. Copy `.env.example` values into the host's environment settings.
3. Set a strong `SESSION_SECRET` and `ADMIN_PASSWORD`.
4. Install dependencies: `npm install`
5. Start: `npm start`
6. Open `http://localhost:3000`

The first admin is created on first boot only when `ADMIN_PASSWORD` is set.
Additional admins are created inside Admin > Admins.

## Phone-first hosting path

Use a Node.js hosting service with a persistent disk/volume, or a development workspace such as Replit:
- Upload/import the project files.
- Add environment variables from `.env.example`.
- Run `npm install`, then `npm start`.
- Use the hosted URL to view the site.

Important: this starter stores data in `data/db.json`. Some free hosting services erase local files or sleep. Use persistent storage for a real public site and back up `data/db.json`. For production, configure HTTPS, secure session secret, persistent storage, and rate limiting.

Do not put account passwords, Steam credentials, or private keys into public fields. This project is not a Steam account authentication system.
